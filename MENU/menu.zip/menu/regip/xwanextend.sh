#!/bin/bash
export HOME=/root
export TERM=xterm
NC='\e[0m'
dateFromServer=$(curl -v --insecure --silent https://google.com/ 2>&1 | grep Date | sed -e 's/< Date: //')
biji=$(date +"%Y-%m-%d" -d "$dateFromServer")
ipsaya=$(curl -sS ipv4.icanhazip.com)
data_server=$(curl -v --insecure --silent https://google.com/ 2>&1 | grep Date | sed -e 's/< Date: //')
date_list=$(date +"%Y-%m-%d" -d "$data_server")
data_ip="https://raw.githubusercontent.com/riski12345/vip/main/izin"

checking_sc() {
  useexp=$(wget -qO- $data_ip | grep $ipsaya | awk '{print $3}')
  if [[ $date_list < $useexp ]]; then
    echo -ne
  else
    echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
    echo -e "\033[42m          ANDA HARUS MENDAFTAR DAHULU UNTUK MENJADI SELLER         \033[0m"
    echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
    echo -e ""
    echo -e "            ${RED}DAFTAR DULU DEK !${NC}"
    echo -e "   \033[0;33mYour VPS${NC} $ipsaya \033[0;33mHas been Banned${NC}"
    echo -e "     \033[0;33mBuy access permissions for scripts${NC}"
    echo -e "             \033[0;33mContact Admin :${NC}"
    echo -e "      \033[0;36mTelegram${NC} t.me/kytxz"
    echo -e "      ${GREEN}WhatsApp${NC} wa.me/6287769315399"
    echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
    exit
  fi
}
checking_sc
Repo1="https://raw.githubusercontent.com/riski12345/vip/main/"
export MYIP=$(curl -sS ipv4.icanhazip.com/)
SELLER=$(curl -sS ${Repo1}izin | grep $MYIP | awk '{print $2}')
Exp100=$(curl -sS ${Repo1}izin | grep $MYIP | awk '{print $3}')
data_ip="https://raw.githubusercontent.com/riski12345/vip/main/izin"
d2=$(date -d "$date_list" +"+%s")
d1=$(date -d "$Exp" +"+%s")
dayleft=$((($d1 - $d2) / 86400))
####
TOKEN="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"
REPO="https://github.com/Mrz051/vip2.git"
EMAIL="fa4573620@gmail.com"
USER="Mrz051"
today=$(date -d "0 days" +"%Y-%m-%d")
#####

# Ambil parameter dari perintah renewip
ip="$1"
days="$2"

git clone ${REPO} /root/ipvps/
CLIENT_EXISTS=$(grep -w $ip /root/ipvps/izin | wc -l)
if [[ ${CLIENT_EXISTS} != '1' ]]; then
  echo "IP does not exist!"
  rm -rf /root/ipvps
  exit 0
fi

name=$(grep -w $ip /root/ipvps/izin | awk '{print $2}')
exp=$(grep -w $ip /root/ipvps/izin | awk '{print $3}')
d1=$(date -d "$exp" +%s)
d2=$(date +%s)
exp2=$(( (d1 - d2) / 86400 ))
exp3=$(($exp2 + $days))
exp4=$(date -d "$exp3 days" +"%Y-%m-%d")

sed -i "s/### $name $exp $ip/### $name $exp4 $ip/g" /root/ipvps/izin

cd /root/ipvps
git config --global user.email "${EMAIL}"
git config --global user.name "${USER}"
rm -rf .git &> /dev/null
git init &> /dev/null
git add . &> /dev/null
git commit -m "Renewed IP $ip" &> /dev/null
git branch -M master &> /dev/null
git remote add origin https://github.com/Mrz051/vip2.git
git push -f https://${TOKEN}@github.com/Mrz051/vip2.git &> /dev/null
rm -rf /root/ipvps

echo -e "━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo -e "🍀VPS SUCCESSFULLY RENEWED🍀"
echo -e "━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo -e "🌹NAME AUTHOR : $name"
echo -e "🏵️NEW EXPIRY DATE : $exp4"
echo -e "🌺IP SERVER   : $ip"
echo -e "━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
